# deploy-lambda.ps1

param(
    [string]$LambdaFunctionName = "",
    [string]$SourcePath = "",
    [string]$AwsProfile = ""
)

function Prompt-For-Input {
    param(
        [string]$Prompt,
        [string]$Default = ""
    )
    if ($Default) {
        $promptString = "$Prompt [$Default]: "
    } else {
        $promptString = "$($Prompt): "
    }
    $input = Read-Host $promptString
    if ($input) { return $input } else { return $Default }
}

# --- Prompt for input if not provided ---
if (-not $LambdaFunctionName) { $LambdaFunctionName = Prompt-For-Input "Enter Lambda function name" }
if (-not $SourcePath) { $SourcePath = Prompt-For-Input "Enter path to your Lambda source code folder" "." }
if (-not $AwsProfile) { $AwsProfile = Prompt-For-Input "Enter AWS CLI profile name (as configured with 'aws configure sso')" }

Write-Host "`nUsing AWS CLI profile: $AwsProfile"

# --- Refresh SSO session if needed ---
try {
    aws sts get-caller-identity --profile $AwsProfile | Out-Null
} catch {
    Write-Host "Refreshing AWS SSO session (if needed)..."
    aws sso login --profile $AwsProfile
}

# --- Create zip filename (always clean up old zip) ---
$zipName = "$LambdaFunctionName-deploy.zip"
$zipPath = Join-Path $PWD $zipName
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

# --- Zipping everything recursively (including hidden files/folders) ---
Write-Host "Zipping code from $SourcePath ..."
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Zip-AllContent {
    param(
        [string]$SourceDir,
        [string]$DestinationZip
    )
    # Remove if existing
    if (Test-Path $DestinationZip) { Remove-Item $DestinationZip -Force }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($SourceDir, $DestinationZip)
}

# Make sure the zipping includes all subfolders/files:
Zip-AllContent -SourceDir $SourcePath -DestinationZip $zipPath

# --- Deploy to Lambda ---
Write-Host "Uploading code to Lambda function: $LambdaFunctionName ..."
$updateCmd = "aws lambda update-function-code --function-name $LambdaFunctionName --zip-file fileb://$zipPath --profile $AwsProfile"
Invoke-Expression $updateCmd

Write-Host "`nDeployment complete.`n"
